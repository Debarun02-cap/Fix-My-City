//Local Module
const citizenController=require('../controller/citizen')
const upload = require('../utils/uploadUtil');

//External MOdule
const express=require('express');

const ur=express();

ur.get('/home',citizenController.userHome);
ur.get('/register',citizenController.getRegister);
ur.post('/register', upload.single('photo'), citizenController.postRegister);
ur.get('/complaintDetails/:complaintId',citizenController.getComplaintDetails);

exports.ur=ur;
