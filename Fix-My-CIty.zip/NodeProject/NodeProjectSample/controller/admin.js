//Local Modules
const Complaint = require("../models/complaint");
const Status = require("../models/status");
const Photo = require("../models/photo");

exports.adminHome=(req,res,next)=>{
  Complaint.fetchAll((registeredComplaints)=>{
    const ids = registeredComplaints.map(c=>c.id);
    Status.getLatestForIds(ids,(statusMap)=>{
      res.render('admin/home',{
        registeredComplaints:registeredComplaints,
        statusMap:statusMap,
        isLoggedIn:req.isLoggedIn
      });
    });
  });
}
exports.getComplaintDetails=(req,res,next)=>{
  const complaintId=req.params.complaintId;
  Complaint.findById(complaintId,complaint=>{
    if(!complaint){
      console.log("Error");
      return res.redirect('/admin/home');
    }

    Status.getForComplaint(complaintId,(statusUpdates)=>{
      res.render('admin/complaintDetails',{
        complaint:complaint,
        statusUpdates:statusUpdates,
        isLoggedIn:req.isLoggedIn
      });
    });
  });
}

exports.getupdateStatus=(req,res,next)=>{
  const complaintId = req.params.complaintId;
  res.render('admin/statusUpdate',{complaintId:complaintId,isLoggedIn:req.isLoggedIn});
}

exports.postUpdateStatus=(req,res,next)=>{
  const complaintId = req.params.complaintId;
  const {workstatus,title,description,dateTime} = req.body;

  // Handle photo upload - save to MongoDB
  if (req.file) {
    Photo.savePhoto(req.file.buffer, req.file.mimetype, (err, photoId) => {
      if (err) {
        console.error('Error saving photo:', err);
        return res.status(500).send('Error saving photo');
      }

      const status = new Status(workstatus,title,description,photoId,dateTime);
      if (req.session && req.session.user) {
        status.userId = req.session.user.id;
      }

      Status.addToStatus(complaintId,status,(err)=>{
        if(err){
          console.error('Failed to save status:',err);
          return res.status(500).send('Failed to save status update');
        }
        res.redirect('/admin/home');
      });
    });
  } else {
    // No photo uploaded
    const status = new Status(workstatus,title,description,'',dateTime);
    if (req.session && req.session.user) {
      status.userId = req.session.user.id;
    }

    Status.addToStatus(complaintId,status,(err)=>{
      if(err){
        console.error('Failed to save status:',err);
        return res.status(500).send('Failed to save status update');
      }
      res.redirect('/admin/home');
    });
  }
}