const User = require('../models/user');

exports.getIndex=(req,res,next)=>{
  res.render('auth/index');
}

exports.getLogin=(req,res,next)=>{
  res.render('auth/login');
}

exports.postLogin=(req,res,next)=>{
  const {username,password,role} = req.body;
  console.log('Login attempt:', username, role);

  User.findByCredentials(username,password,role,(user)=>{
    if(!user){
      return res.status(401).render('auth/login',{
        errorMessage:'Invalid credentials. Please check email/mobile, password, and role.'
      });
    }

    req.session.user = {
      id: user.id,
      role: user.role,
      name: user.firstname
    };

    res.redirect('/');
  });
}

exports.getSignup=(req,res,next)=>{
  res.render('auth/signup');
}

exports.postSignup=(req,res,next)=>{
  const {firstname,lastname,email,mobile,address,city,state,aadhar,password,role} = req.body;
  const user = new User(firstname,lastname,email,mobile,address,city,state,aadhar,password,role);

  user.save().then(()=>{
    res.redirect('/auth/login');
  });
}

exports.postLogout=(req,res,next)=>{
  req.session.destroy(err=>{
    res.redirect('/');
  });
}